<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeedbackStatus extends Model
{
    protected $table = 'feedback_status';
    protected $primaryKey = 'id';
}
