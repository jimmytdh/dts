<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tracking_Releasev2 extends Model
{
    protected $table = 'tracking_releasev2';
    protected $primaryKey = 'id';
}
