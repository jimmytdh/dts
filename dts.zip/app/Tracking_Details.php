<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tracking_Details extends Model
{
    protected $table = 'tracking_details';
    protected $primaryKey = 'id';
}
