<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemLogs extends Model
{
    protected $table = 'systemlogs';
    protected $primaryKey = 'id';
}
