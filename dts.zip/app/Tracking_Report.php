<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tracking_Report extends Model
{
    protected $table = 'tracking_report';
    protected $primaryKey = 'id';
}
