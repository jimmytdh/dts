<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>Learning Laravel!!</h2>
<div>
    Welcome to {!! $name !!} website!
    <a href="{{ asset('/') }}"><img src="https://www.google.com/images/branding/product/ico/googleg_lodp.ico" class="img-responsive" /></a>
</div>

</body>
</html>