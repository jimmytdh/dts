
<html>
<style type="text/css">
    html {
        margin-top:950px;
        margin-left:280px;
    }
</style>
<body>
<?php echo DNS1D::getBarcodeHTML($route_no,"C39E",1,33); ?>
{{ $route_no }}
</body>
</html>


