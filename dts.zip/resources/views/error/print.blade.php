
@extends('layouts.app')

@section('content')
    <h2>System errors and excemptions.</h2>
    <blockquote>
        {{ $error }}
    </blockquote>
@endsection